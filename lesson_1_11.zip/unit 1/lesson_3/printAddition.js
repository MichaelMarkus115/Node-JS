const additionModule = require("./addition");

// let ans = additionModule.addnum(3,2);

console.log(additionModule.addnum(3,2));

// console.log(ans);