const cities = require("cities");

let myCities = cities.zip_lookup("10016");
console.log(myCities);
