exports.addnum = (x, y) => {
    return x + y;
};